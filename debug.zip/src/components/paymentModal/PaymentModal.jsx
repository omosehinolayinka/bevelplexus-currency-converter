import React from 'react'

function paymentModal() {
  return (
    <div>
      
    </div>
  )
}

export default paymentModal
