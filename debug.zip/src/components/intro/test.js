// import React from 'react'

// const GetFxRates = () => {
  

  
// };

// export default GetFxRates