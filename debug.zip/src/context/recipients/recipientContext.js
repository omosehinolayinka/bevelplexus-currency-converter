import { createContext } from 'react';

const recipientContext = createContext();

export default recipientContext;