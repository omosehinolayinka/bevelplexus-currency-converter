import { createContext } from 'react'

const paymentContext = createContext();

export default paymentContext;