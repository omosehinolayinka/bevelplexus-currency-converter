import { createContext } from 'react';

const transactionContext = createContext();

export default transactionContext;