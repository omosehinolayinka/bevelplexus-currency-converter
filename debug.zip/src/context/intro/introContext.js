import { createContext } from 'react';

const introContext = createContext();

export default introContext;